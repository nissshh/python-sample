import unittest
import os
import json
from transfer.dealertransfer_client_lambda import lambda_handler
class TestDealerTransferLambda(unittest.TestCase):
    def test_send_dealer_transfer_success(self):
        os.environ['AWS_REGION']="us-east-1"
        os.environ['base_url']="https://jdwarrantysystem.tal.deere.com/"
        os.environ['recommendations_trace_table']="channelwarranty.trace.dealers.recommendations"
        os.environ['recommendations_table']="channelwarranty.dealers.recommendations"
        os.environ['client_id_key']="CHANNEL/JDWS/Okta_ClientId"
        os.environ['client_secret_key']="CHANNEL/JDWS/Okta_Client_Secret"
        os.environ['oauth_url']="https://sso-dev.johndeere.com/oauth2/ausgnh3p6ag71v8gs0h7"
        os.environ['redis_endpoint'] = "channelwarrantyelasticcache.apps-devl-vpn.us.i06.c01.johndeerecloud.com"
        os.environ['redis_port'] = "6379"
        event_str="{\"Records\": [{\"messageId\": \"19dd0b57-b21e-4ac1-bd88-01bbb068cb78\", \"receiptHandle\": \"MessageReceiptHandle\", \"body\": \"{\\\"product\\\": {\\\"pin\\\": \\\"1GXD125ECFF620950\\\", \\\"customerSummary\\\": {\\\"id\\\": \\\"0310447388\\\"}}, \\\"currentDealer\\\": {\\\"account\\\": \\\"010030\\\"}, \\\"newDealer\\\": {\\\"account\\\": \\\"088703\\\"}, \\\"requestDate\\\": 1625840785745, \\\"requestedBy\\\": {\\\"id\\\": \\\"XTPCT12\\\"}, \\\"reasonForChange\\\": \\\"Recommendation Transfers Source ELIPS\\\", \\\"status\\\": \\\"NEW\\\"}\", \"attributes\": {\"ApproximateReceiveCount\": \"1\", \"SentTimestamp\": \"1523232000000\", \"SenderId\": \"123456789012\", \"ApproximateFirstReceiveTimestamp\": \"1523232000001\"}, \"messageAttributes\": {\"http-method\": {\"stringValue\":\"POST\"}, \"url\": {\"stringValue\":\"api/transfers\"}}, \"md5OfBody\": \"{{{md5_of_body}}}\", \"eventSource\": \"aws:sqs\", \"eventSourceARN\": \"arn:aws:sqs:us-east-1:123456789012:MyQueue\", \"awsRegion\": \"us-east-1\"}]}"
        event = json.loads(event_str)
        context =""
        ret_val = lambda_handler(event, context)
        print(ret_val)
        self.assertIsNotNone(ret_val)
    def setUp(self):
        pass
    def tearDown(self):
        pass
    