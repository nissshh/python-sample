import unittest
import os
from transfer.oktatoken_request_builder import OktaOAuthTokenGenerator
from transfer.cache_okta_accesstoken import CacheOktaAccessToken

class TestCacheOktaAccessToken(unittest.TestCase):
    def test_get_cache_access_token(self):
        os.environ['redis_endpoint'] = "channelwarrantyelasticcache.apps-devl-vpn.us.i06.c01.johndeerecloud.com"
        os.environ['redis_port'] = "6379"
        okta = OktaOAuthTokenGenerator("https://sso-dev.johndeere.com/oauth2/ausgnh3p6ag71v8gs0h7","CHANNEL/JDWS/Okta_ClientId","CHANNEL/JDWS/Okta_Client_Secret")
        cacheOktaToken = CacheOktaAccessToken(okta)
        token = cacheOktaToken.get_cache_token()
        self.assertIsNotNone(token)
    def setUp(self):
        pass
    def tearDown(self):
        pass