import unittest
from transfer.oktatoken_request_builder import OktaOAuthTokenGenerator

class TestGenerateToken(unittest.TestCase):
    def test_generate_token_nonnull(self):
        okta = OktaOAuthTokenGenerator("https://sso-dev.johndeere.com/oauth2/ausgnh3p6ag71v8gs0h7","CHANNEL/JDWS/Okta_ClientId","CHANNEL/JDWS/Okta_Client_Secret")
        token = okta.generate_token()
        self.assertIsNotNone(token)
    def setUp(self):
        pass
    def tearDown(self):
        pass