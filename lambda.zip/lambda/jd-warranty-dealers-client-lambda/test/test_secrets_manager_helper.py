import unittest
from transfer.secrets_manager_helper import get_secret

class TestGetSecretMethod(unittest.TestCase):
    def setUp(self):
        pass
    def tearDown(self):
        pass
    def test_get_secret(self):
        sec = get_secret('CHANNEL/JDWS/Okta_ClientId')
        self.assertIsNotNone
        self.assertEqual('0oamrbc1x3rVmuBlK0h7',sec)
        sec = get_secret('CHANNEL/JDWS/Okta_Client_Secret')
        self.assertIsNotNone
        self.assertEqual('8ftFzvy1KtQuKVUPcXm0xPLApWj3_XLeW0Om6GG1',sec)