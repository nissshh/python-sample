import os
import logging
import boto3
import json
import requests

from transfer.dealerrecommendations_trace_table_dao import DealerRecommendationsTraceDAO
from transfer.dealertransfer_request_builder import create_query_params,create_payload
from transfer.dynamodb_adapter import DynamoAdapter
from transfer.dealer_transfer_service import DealerTransferService

logger = logging.getLogger()
logger.setLevel(logging.INFO)


RECIEVED_DEALER_TRANSFER_QUEUED_PAYLOAD='RECIEVED_DEALER_TRANSFER_QUEUED_PAYLOAD'

def lambda_handler(event, context):
    try:
        '''
            Lambda Handler to perfrom dealer transfer based on parameters passed.
        '''
        ##Get Vars and Configurations for Payload sent.
        eventRecords = event['Records'][0]
        payload = eventRecords['body']
        api = eventRecords['messageAttributes']['url']['stringValue']
        method_type = eventRecords['messageAttributes']['http-method']['stringValue']
        base_url = os.environ['base_url']
        recommendation_table= os.environ['recommendations_table']
        recommendation_trace_table= os.environ['recommendations_trace_table']
        url = base_url + api
        logger.debug(f'Calling endpoint {url} & method {method_type} with payload as {payload}')
        requestpayload = json.loads(payload)
               
        
        dealer_transfer_reco_trace_dao=DealerRecommendationsTraceDAO()
        dealer_transfer_service=DealerTransferService(recommendation_table)

        getrow = dealer_transfer_reco_trace_dao.get_event_trace(create_query_params(requestpayload))
        ## Add trace data
        if getrow:
            traceid = getrow[0]['id']
        else:
            tracePayload = create_payload(requestpayload)
            dealer_transfer_table = DynamoAdapter(recommendation_trace_table)
            dealer_transfer_table.put_item(tracePayload)
            traceid = tracePayload['id']
    
        dealer_transfer_reco_trace_dao.add_event_to_trace(traceid, RECIEVED_DEALER_TRANSFER_QUEUED_PAYLOAD,'')
        dealer_transfer_service.call_dealer_transfer_service(url,requestpayload,method_type,traceid)

    except Exception as e:
        logger.error('Error Occured in Lambda Execution {}'.format(e))
    else:
        logger.debug("Lambda execution completed Successfully.")
        return 'The region used is {}'.format(os.environ['AWS_REGION'])

if __name__ == "__main__":
        os.environ['AWS_REGION']="us-east-1"
        os.environ['base_url']="https://jdwarrantysystem.tal.deere.com/"
        os.environ['recommendations_trace_table']="channelwarranty.trace.dealers.recommendations"
        os.environ['recommendations_table']="channelwarranty.dealers.recommendations"
        os.environ['client_id_key']="CHANNEL/JDWS/Okta_ClientId"
        os.environ['client_secret_key']="CHANNEL/JDWS/Okta_Client_Secret"
        os.environ['oauth_url']="https://sso-dev.johndeere.com/oauth2/ausgnh3p6ag71v8gs0h7"
        os.environ['redis_endpoint']="channelwarrantyelasticcache.apps-devl-vpn.us.i06.c01.johndeerecloud.com"
        os.environ['redis_port']="6379"

        ##event="{\"Records\":[{\"messageId\":\"19dd0b57-b21e-4ac1-bd88-01bbb068cb78\",\"receiptHandle\":\"MessageReceiptHandle\",\"body\":\"{'product': {'pin': '1GXD125ECFF620950', 'customerSummary': {'id': '0310447388'}}, 'currentDealer': {'account': '010030'}, 'newDealer': {'account': '088703'}, 'requestDate': 1625840785745, 'requestedBy': {'id': 'XTPCT12'}, 'reasonForChange': 'Recommendation Transfers Source ELIPS', 'status': 'NEW'}\",\"attributes\":{\"ApproximateReceiveCount\":\"1\",\"SentTimestamp\":\"1523232000000\",\"SenderId\":\"123456789012\",\"ApproximateFirstReceiveTimestamp\":\"1523232000001\"},\"messageAttributes\":{\"http-method\":\"POST\",\"url\":\"api/transfers\"},\"md5OfBody\":\"{{{md5_of_body}}}\",\"eventSource\":\"aws:sqs\",\"eventSourceARN\":\"arn:aws:sqs:us-east-1:123456789012:MyQueue\",\"awsRegion\":\"us-east-1\"}]}"
        event_str="{\"Records\": [{\"messageId\": \"19dd0b57-b21e-4ac1-bd88-01bbb068cb78\", \"receiptHandle\": \"MessageReceiptHandle\", \"body\": \"{\\\"product\\\": {\\\"pin\\\": \\\"1GXD125ECFF620950\\\", \\\"customerSummary\\\": {\\\"id\\\": \\\"0310447388\\\"}}, \\\"currentDealer\\\": {\\\"account\\\": \\\"010030\\\"}, \\\"newDealer\\\": {\\\"account\\\": \\\"088703\\\"}, \\\"requestDate\\\": 1625840785745, \\\"requestedBy\\\": {\\\"id\\\": \\\"XTPCT12\\\"}, \\\"reasonForChange\\\": \\\"Recommendation Transfers Source ELIPS\\\", \\\"status\\\": \\\"NEW\\\"}\", \"attributes\": {\"ApproximateReceiveCount\": \"1\", \"SentTimestamp\": \"1523232000000\", \"SenderId\": \"123456789012\", \"ApproximateFirstReceiveTimestamp\": \"1523232000001\"}, \"messageAttributes\": {\"http-method\": {\"stringValue\":\"POST\"}, \"url\": {\"stringValue\":\"api/transfers\"}}, \"md5OfBody\": \"{{{md5_of_body}}}\", \"eventSource\": \"aws:sqs\", \"eventSourceARN\": \"arn:aws:sqs:us-east-1:123456789012:MyQueue\", \"awsRegion\": \"us-east-1\"}]}"
        event = json.loads(event_str)
        context =""
        ret_val = lambda_handler(event, context)
        print(ret_val)