import requests
import json
import os
import boto3
import logging

from transfer.secrets_manager_helper import  get_secret

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class OktaOAuthTokenGenerator:
    '''
    The class will generate okta token for a given client key using client credentials flow.
    '''
    def __init__(self,auth_server_url,client_id_key,client_secret_key):
        self.auth_server_url=auth_server_url
        self.client_id_key=client_id_key
        self.client_secret_key=client_secret_key

    def construct_headers(self,access_token):
        return {
            "content-type": "application/json",
            "Authorization": "Bearer "+access_token
        }

    def construct_okta_headers(self):
        return {
            "accept": "application/json",
            "cache-control": "no-cache",
            "content-type": "application/x-www-form-urlencoded"
        }

    def create_okta_payload(self):
        return {
            'grant_type': 'client_credentials',
            'scope': '',
            'client_id':  get_secret(self.client_id_key),
            'client_secret': get_secret(self.client_secret_key)
        }

    def generate_token(self):
        data = self.create_okta_payload()
        headers = self.construct_okta_headers()
        result = requests.post(self.auth_server_url+"/v1/token", data , headers)
        if result.status_code == 200:
            return json.loads(result.content)['access_token']
        else:
            raise Exception(f"Cannot Generate access token for given client {self.client_id_key}")

    def validate_token_expiry(self, access_token):
         introspect_url = self.auth_server_url+"/v1/introspect?client_id=" + get_secret(self.client_id_key) + "&client_secret=" + get_secret(self.client_secret_key) + "&token=" + access_token + "&token_type_hint=access_token"
         headers = self.construct_okta_headers()
         return requests.post(introspect_url, headers)
