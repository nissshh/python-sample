import uuid
from datetime import datetime
from boto3.dynamodb.conditions import Key

def create_payload(payload):
    return {
        'id': str(uuid.uuid4()),
        'new_dealer': payload['newDealer']['account'],
        'current_dealer': payload['currentDealer']['account'],
        'pin': payload['product']['pin'],
        'trace': [create_trace_payload('SQS_QUEUED_SUCCESS',str(payload))]
    }

def create_trace_payload(statustitle,messagetext):
    return {
        'create_ts': str(datetime.now().strftime("%d/%m/%Y %H:%M:%S")),
        'status': statustitle,
        'text': messagetext
    }

def create_query_params(payload):
    return {
        'ProjectionExpression': "id",
        'FilterExpression': Key('pin').eq(payload['product']['pin']) &
                            Key('new_dealer').eq(str(payload['newDealer']['account'])) &
                            Key('current_dealer').eq(str(payload['currentDealer']['account']))
    }

'''
def update_trace_table(id, message):
    return 
    {
	    "Key": "{'id': [id]}",
	    "UpdateExpression": "SET trace = list_append(trace, :trace)",
	    "ExpressionAttributeValues": {
		    ":trace": [message]
	    },
	    "ReturnValues": "UPDATED_NEW"
    }   

def update_recommendation_table(recommendationid, transferstatus):
    return (
        Key={"id":recommendationid},
        UpdateExpression="SET #transferstatus = :transferstatus,update_ts = :updatets",
        ExpressionAttributeValues={
            ':transferstatus': transferstatus,
            ':updatets': str(datetime.now().strftime("%m/%d/%Y %H:%M:%S"))
        },
        ExpressionAttributeNames={
            "#transferstatus": "status"
        },
        ReturnValues="UPDATED_NEW"  
)
'''