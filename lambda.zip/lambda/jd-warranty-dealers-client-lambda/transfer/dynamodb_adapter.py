import boto3
import os
from datetime import datetime
## table dynamodb object at class leve as init code self.dynamodb- 
class DynamoAdapter:
    def __init__(self,table_name):
        self.dynamodb = boto3.resource('dynamodb', os.environ['AWS_REGION'])
        self.table_name=table_name

    def get_item(self, scan_kwargs):
        return self.dynamodb.Table(self.table_name).scan(**scan_kwargs)['Items']

    def put_item(self, new_payload):
        self.dynamodb.Table(self.table_name).put_item(Item=new_payload)

    def update_item(self, **upd_kwags):
        self.dynamodb.Table(self.table_name).update_item(**upd_kwags)

    