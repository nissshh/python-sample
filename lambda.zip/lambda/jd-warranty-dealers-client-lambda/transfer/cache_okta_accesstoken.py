import json
import os
import redis
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class CacheOktaAccessToken:
    '''
    The class will generate okta token for a given client key using client credentials flow.
    '''
    def __init__(self,okta):
        self.okta = okta
        self.redisobject = redis.StrictRedis(host=os.environ['redis_endpoint'], port=os.environ['redis_port'], db=0)

    def get_cache_token(self):
        access_token = self.redisobject.get("accesstoken::jdwsCloud")
        if access_token is not None:
            access_token = access_token.decode("utf-8")
            responseStr = self.okta.validate_token_expiry(access_token)
            response =json.loads(responseStr.text)
            if responseStr.status_code == 200 and not response['active']:
                access_token = self.okta.generate_token()
                self.redisobject.set("accesstoken::jdwsCloud", access_token)
        else:
            access_token = self.okta.generate_token()
            self.redisobject.set("accesstoken::jdwsCloud", access_token)
        return access_token