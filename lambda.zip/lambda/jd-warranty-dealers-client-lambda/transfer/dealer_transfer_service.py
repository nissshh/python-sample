import os
import json
import logging
import requests

from transfer.dynamodb_adapter import DynamoAdapter
from transfer.oktatoken_request_builder import OktaOAuthTokenGenerator
from transfer.dealerrecommendations_trace_table_dao import DealerRecommendationsTraceDAO
from transfer.dealertransfer_request_builder import create_query_params,create_payload,create_trace_payload
from datetime import datetime
from transfer.cache_okta_accesstoken import CacheOktaAccessToken

logger = logging.getLogger()
logger.setLevel(logging.INFO)

DEALER_TRANSFER_PORTAL_SERVICE_STARTED = 'DEALER_TRANSFER_PORTAL_SERVICE_STARTED'
DEALER_TRANSFER_PORTAL_SERVICE_FAILED = 'DEALER_TRANSFER_PORTAL_SERVICE_FAILED'
DEALER_TRANSFER_PORTAL_SERVICE_SUCCEED='DEALER_TRANSFER_PORTAL_SERVICE_SUCCEED'
DEALER_TRANSFER_PORTAL_SERVICE_ENDED='DEALER_TRANSFER_PORTAL_SERVICE_ENDED'
SUBMITTED='SUBMITTED'

class DealerTransferService:
    '''
        A Service Implementation class for performing DealerTransfer Operations.
    '''
    def __init__(self,table):
        '''
            table: DynamoDB table name to write transfer recommendation to.
        '''
        self.dealer_transfer_reco_db=DynamoAdapter(table)
        self.dealer_transfer_reco_trace_dao=DealerRecommendationsTraceDAO()
        client_id_key = os.environ['client_id_key']
        client_secret_key = os.environ['client_secret_key']
        oauth_url=os.environ['oauth_url']
        self.okta=OktaOAuthTokenGenerator(oauth_url,client_id_key,client_secret_key)
        self.access_token = CacheOktaAccessToken(self.okta).get_cache_token()
    
    def call_dealer_transfer_service(self,url,payload,http_method, traceid):
        '''
        Calls Dealer Transfer Service for given url and payload, also adds
        data to trace table as configured with this service.
        '''
        logger.debug("Calling  call_dealer_transfer_service Started")
        headers = self.okta.construct_headers(self.access_token)
        logger.debug('actual call_dealer_transfer_service Started payloadrequest: {}'.format(payload))

        self.dealer_transfer_reco_trace_dao.add_event_to_trace(traceid,DEALER_TRANSFER_PORTAL_SERVICE_STARTED,'')

        result = requests.post(url, data=json.dumps(payload), headers=headers)

        logger.info('Recieved Portal Response Status Code : as {} and Payload as {}'.format(result.status_code,result._content))

        recommendationstatus = SUBMITTED
        if result.status_code != 201:
            logger.error('Error while calling Portal api {} , error {}'.format(url, result.text))
            recommendationstatus = 'ERRORED'
            self.dealer_transfer_reco_trace_dao.add_event_to_trace(traceid, DEALER_TRANSFER_PORTAL_SERVICE_FAILED, result.text)
        else:
            self.dealer_transfer_reco_trace_dao.add_event_to_trace(traceid, DEALER_TRANSFER_PORTAL_SERVICE_SUCCEED, '{status:'+recommendationstatus+'}')
            logger.info('API executed successfully api {}, status {}'.format(url,result.status_code))
        #For sequences, (strings, lists, tuples), use the fact that empty sequences are false
        if recommendationstatus:
            query_param = create_query_params(payload)
            getrow = self.dealer_transfer_reco_db.get_item(query_param)
            if getrow:
                recommendationid = getrow[0]['id']
                self.dealer_transfer_reco_db.update_item(
                        Key={"id":recommendationid},
                        UpdateExpression="SET #transferstatus = :transferstatus,update_ts = :updatets",
                        ExpressionAttributeValues={
                            ':transferstatus': recommendationstatus,
                            ':updatets': str(datetime.now().strftime("%m/%d/%Y %H:%M:%S"))
                        },
                        ExpressionAttributeNames={
                            "#transferstatus": "transfer_status"
                        },
                        ReturnValues="UPDATED_NEW"
                    )
            else:
                logger.error('No Record found for the given  query_param {}'.format(query_param))
                self.dealer_transfer_reco_db.put_item(create_payload(payload))

        self.dealer_transfer_reco_trace_dao.add_event_to_trace(traceid,DEALER_TRANSFER_PORTAL_SERVICE_ENDED,'') ## ths wil be recommendation updates.
        logger.debug('call_dealer_transfer_service Completed')