import os
import sys
import logging

from transfer.dynamodb_adapter import DynamoAdapter
from transfer.dealertransfer_request_builder import create_trace_payload,create_query_params

logger = logging.getLogger()
logger.setLevel(logging.INFO)

class DealerRecommendationsTraceDAO:
    '''
        A Dao Class whose sole purpose is to abstract data persistence 
        and provide helper methods to save objects.
    '''
    def __init__(self):
        self.trace_table = os.environ['recommendations_trace_table']
        self.dynamoAdapter = DynamoAdapter(self.trace_table)
    
    def add_event_to_trace(self,traceid,title,message):
        '''Method will be used to build and add event to tracing'''
        traceMessage = create_trace_payload(title, message)
        self.dynamoAdapter.update_item(
            Key={'id': traceid},
            UpdateExpression="SET trace = list_append(trace, :trace)",
            ExpressionAttributeValues={
                ':trace': [traceMessage],
            }, ReturnValues="UPDATED_NEW")
        logger.debug('add_event_to_trace message : {} successfully'.format(title))
    
    def get_event_trace(self,payload):
        ''' Gets the event trace paylaod on the basis of filter '''
        return self.dynamoAdapter.get_item(payload)