# jd-warranty-dealers-client-lambda
This will be a component that will call the Dealer Services on Portal such as transfers
