from pathlib import Path
from dotenv import load_dotenv
import requests
import logging
import json
import os
import gc
import boto3
logger = logging.getLogger()

############Environment Variables############
base_bucket = os.environ.get('BASE_BUCKET','aws-channel-apps-devl-warranty')
environment = os.environ.get('ENVIRONMENT','devl')
okta_token_file_key = os.environ.get('OKTA_TOKEN_FILE_KEY','DataMigrationToDynamoDb/referenceFiles/token.txt')
log_level = os.environ.get('LOG_LEVEL','DEBUG')
logger.setLevel(log_level)

dirname = os.path.dirname(__file__)
env_path=dirname+'/env/'+environment+'.env'
dotenv_path = Path(env_path)
load_dotenv(dotenv_path=dotenv_path)
token_url = os.environ.get('TOKEN_URL')
token_client_details = os.environ.get('TOKEN_CLIENT_DETAILS')

######S3 Connection######
s3 = boto3.resource('s3')

def get_token(url,re_data):
    headers = {'content-Type':'application/x-www-form-urlencoded'}
    r = requests.post(url,data=re_data,headers=headers)
    if r.status_code != 200:
        logger.error('Error in receiving token')
        raise Exception('Error in receiving token')
    access_token = json.loads(r.text)['access_token']
    return 'Bearer '+access_token

def write_token_to_s3(oktaToken, fileNameWithS3Path):
    logger.debug('Start write_json_to_s3')
    logger.info('okta token is: {} ,filename is : {} '.format(oktaToken,fileNameWithS3Path))
    
    s3object = s3.Object(base_bucket, fileNameWithS3Path)
    response = s3object.put(Body=(bytes(oktaToken, encoding='utf8')))
    logger.debug('End write_json_to_s3')
    return response


def lambda_handler(event, context):
    logger.info('Lambda Started') 
    try:
        token = get_token(token_url,token_client_details)
        logger.info('Received token : {}'.format(token))
        response = write_token_to_s3(token,okta_token_file_key)
        if(response['ResponseMetadata']['HTTPStatusCode'] == 200):
            logger.info('Returning successful response code')
            return "success"
        else:
            logger.error('Write to s3 failed')
            return "failure"
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
        gc.collect()    
        raise Exception({'message':'failed at authTokenGenerator lambda_handler', 'notificationCode':'', 'exception': format(e)})
    finally:
        logger.info('Lambda End')

if __name__ == "__main__":
    response = lambda_handler(None, None)
    print(response)