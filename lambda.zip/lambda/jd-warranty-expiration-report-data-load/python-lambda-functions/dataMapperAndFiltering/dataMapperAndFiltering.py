'''
Created on Jul 9, 2021

@author: nl02115
'''
import logging
import boto3
import os
import gc
import json
from datetime import datetime
from botocore.exceptions import ClientError

base_bucket = os.environ.get('BASE_BUCKET','aws-channel-apps-devl-warranty')
coverage_data_mapper_keys = os.environ.get('COV_DATA_MAPPER_KEYS','DataMigrationToDynamoDb/referenceFiles/coverage_data_mapper_keys.json')
logger = logging.getLogger()
lambda_log_level=os.getenv('LOG_LEVEL','DEBUG')
logger.setLevel(lambda_log_level)

json_source_s3_folder = os.environ.get('JSON_SOURCE_S3_FOLDER','DataMigrationToDynamoDb/jsonData/')
json_target_s3_folder = os.environ.get('JSON_TARGET_S3_FOLDER','DataMigrationToDynamoDb/jsonData/')
success_s3_folder = os.environ.get('SUCCESS_S3_FOLDER','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/dataMapperAndFiltering/success/')
failure_s3_folder = os.environ.get('FAILURE_S3_FOLDER','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/dataMapperAndFiltering/failure/')

s3 = boto3.resource('s3')
dynamodb = boto3.resource('dynamodb')

dynamoDBCoverageRecordTable = 'channelwarranty.coverage.records'
dateAttributesToLongConvert = ['expirationDate','contractPurchaseDate'] 
cancelIndicatorAttribute = 'warranty_cancel_ind'
cancelIndicatorValue = 'X'
dealerAttributeIdentifier = 'dealer'
rawDealerAttributeIdentifier = 'responsible_dealer'
warrProdPkAttributeIdentifier = 'warr_prod_pk'
createdTsAttributeIdentifier = 'created_dt'


def write_json_to_s3(jsonArray, fileNameWithS3Path):   
    logger.debug('Start write_json_to_s3') 
    logger.info('json_array is: {} ,filename is : {} '.format(jsonArray,fileNameWithS3Path))
    
    s3object = s3.Object(base_bucket, fileNameWithS3Path)
    response = s3object.put(
        Body=(bytes(json.dumps(jsonArray,indent=4).encode('UTF-8')))
    )
    logger.debug('End write_json_to_s3') 
    return response
 
def get_s3_file(fileName):
    obj = s3.Object(bucket_name= base_bucket, key= fileName).get()['Body']
    return obj

def convert_date_to_millisec(stringDate):
    dt_obj = datetime.strptime(stringDate, '%Y-%m-%d')
    millisec = dt_obj.timestamp() * 1000
    return round(millisec)

def delete_cancel_warranty_frm_dynamo(jsonData):
    logger.info('Start delete_cancel_warranty_frm_dynamo')

    table = dynamodb.Table(dynamoDBCoverageRecordTable)

    try:
        logger.info('Delete from dynamo DB dealer : {} and warr_prod_pk : {}'.format(jsonData[rawDealerAttributeIdentifier], jsonData[warrProdPkAttributeIdentifier]))
        response = table.delete_item(
            Key={
                dealerAttributeIdentifier: jsonData[rawDealerAttributeIdentifier],
                warrProdPkAttributeIdentifier: int(jsonData[warrProdPkAttributeIdentifier])
            }
        )
        logger.info('Delete response is : {}'.format(response))
    except ClientError as e:
        logger.error('Exception Occured while deleting : {}'.format(e))
    

    
def map_and_filter_data(jsonDataArray , dataMapperKeysDict):
    logger.info('Start map_filter_data')
    
    resultJsonDataArray = []
    duplicateCheckDict = dict()
    for data in jsonDataArray:
        if not duplicateCheckDict.get(data[warrProdPkAttributeIdentifier]):
            resultJsonDataDict = dict()
            current_date = datetime.now().strftime('%Y%m%d')
            resultJsonDataDict[createdTsAttributeIdentifier] = current_date
            if data[rawDealerAttributeIdentifier]:
                for dataAttribute in data:
                    if dataAttribute in dataMapperKeysDict:
                        if dataMapperKeysDict[dataAttribute] in dateAttributesToLongConvert:
                            #print(dataAttribute) 
                            if data[dataAttribute] != '':
                                resultJsonDataDict[dataMapperKeysDict[dataAttribute]] = convert_date_to_millisec(data[dataAttribute])
                        elif dataAttribute in cancelIndicatorAttribute:
                            if data[dataAttribute] == cancelIndicatorValue:
                                logger.info('Delete from Dynamo db as Extended Warranty is cancelled : {}'.format(data))
                                delete_cancel_warranty_frm_dynamo(data)
                        elif dataAttribute in warrProdPkAttributeIdentifier:
                            resultJsonDataDict[dataMapperKeysDict[dataAttribute]] = int(data[dataAttribute])
                        else:
                            #print(dataAttribute, data[dataAttribute])
                            resultJsonDataDict[dataMapperKeysDict[dataAttribute]] = data[dataAttribute]
                        
                resultJsonDataArray.append(resultJsonDataDict)
                duplicateCheckDict[data[warrProdPkAttributeIdentifier]] = data[warrProdPkAttributeIdentifier]
            else:
                #Log and trigger SNS for data as empty in dealer attribute
                logger.info('Responsible Dealer is empty')
    #pprint.pprint(resultJsonDataArray)
    logger.info('End map_filter_data')
    return resultJsonDataArray


def fileter_map_write_data_for_expiration_report(jsonDataArray):
    logger.info('Start map_filter_for_expiration_report') 
    dataMapperKeys = get_s3_file(coverage_data_mapper_keys)
    dataMapperKeysDict = json.loads(dataMapperKeys.read())  
    resultJsonDataArray = map_and_filter_data(jsonDataArray, dataMapperKeysDict)
    logger.info('End map_filter_for_expiration_report, resultJsonDataArray is {}'.format(resultJsonDataArray)) 
    return resultJsonDataArray

def remove_file_path_prefix(fullFilePath, sourceS3Folder):
    return fullFilePath[len(sourceS3Folder):] if fullFilePath.startswith(sourceS3Folder) else fullFilePath    

def move_file(sourceFile, targetFile):
    logger.info('In move_file, source file is: {} and target file is: {}'.format(sourceFile, targetFile))
    try:
        s3.Object(base_bucket, targetFile).copy_from(CopySource=base_bucket+'/'+sourceFile)
        s3.Object(base_bucket,sourceFile).delete()   
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))

def lambda_handler(event, context):
    logger.info('Lambda Started') 
    try:
        logger.info('Received Input : {}'.format(json.dumps(event, indent=2)))
        if (event['dataEnrichmentStatus'] == 'success'): 
            inpFile = get_s3_file(event['filename'])
            jsonDataArray = json.loads(inpFile.read())  
            expirationReportJsonDataArray = fileter_map_write_data_for_expiration_report(jsonDataArray)
            #pprint.pprint(expirationReportJsonDataArray)
            logger.info('Expiration Report Data is : {}'.format(expirationReportJsonDataArray)) 
            
            #Move the source file to success folder for archive
            targetSuccessFile = success_s3_folder + remove_file_path_prefix(event['filename'], json_source_s3_folder)
            move_file(event['filename'],targetSuccessFile)
            
            targetFilenameWithFolder = json_target_s3_folder + remove_file_path_prefix(event['filename'], json_source_s3_folder)
            response = write_json_to_s3(expirationReportJsonDataArray, targetFilenameWithFolder)  
            logger.info('Write response is : {}'.format(response))
            if(response['ResponseMetadata']['HTTPStatusCode'] == 200):
                logger.info('Returning successful response code')
                return "success"
        else:
            logger.error('dataEnrichmentStatus is not success')

    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
        gc.collect()
        #Move the source file to failure folder for archive
        targetErrorFile = failure_s3_folder + remove_file_path_prefix(event['filename'], json_source_s3_folder)
        move_file(event['filename'],targetErrorFile)
        raise Exception({'message':'failed at dataMapperAndFiltering lambda_handler', 'notificationCode':'', 'exception': format(e)})
    finally:
        logger.info('Lambda End')
    

if __name__ == "__main__":
    paylod={
      "filename": "DataMigrationToDynamoDb/jsonData/product_warranty_coverage_details-2019-x00/1.json",
      "dataEnrichmentStatus" :  "success"
    }
    jsonDatafilesArray = lambda_handler(paylod, None)
    print(jsonDatafilesArray)
    