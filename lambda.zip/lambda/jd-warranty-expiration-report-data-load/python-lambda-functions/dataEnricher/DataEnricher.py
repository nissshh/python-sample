from pathlib import Path
from dotenv import load_dotenv
import requests
import json
import os
import boto3
import datetime
import logging
import gc
logger = logging.getLogger()

############Environment Variables############
base_bucket = os.environ.get('BASE_BUCKET','aws-channel-apps-devl-warranty')
environment = os.environ.get('ENVIRONMENT','devl')
okta_token_file_key = os.environ.get('OKTA_TOKEN_FILE_KEY','DataMigrationToDynamoDb/referenceFiles/token.txt')
log_level = os.environ.get('LOG_LEVEL','DEBUG')
logger.setLevel(log_level)

json_source_s3_folder = os.environ.get('JSON_SOURCE_S3_FOLDER','DataMigrationToDynamoDb/jsonData/')
success_s3_folder = os.environ.get('SUCCESS_S3_FOLDER','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/dataEnrichment/success/')
failure_s3_folder = os.environ.get('FAILURE_S3_FOLDER','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/dataEnrichment/failure/')


dirname = os.path.dirname(__file__)
env_path=dirname+'/env/'+environment+'.env'

dotenv_path = Path(env_path)
load_dotenv(dotenv_path=dotenv_path)
token_url = os.environ.get('TOKEN_URL')
token_client_details = os.environ.get('TOKEN_CLIENT_DETAILS')
get_accounts_url = os.environ.get('GET_ACCOUNTS_URL')
find_product_url = os.environ.get('FIND_PRODUCT_URL')

######S3 Connection
s3 = boto3.resource('s3')

#TODO Add logging statemetns : info, warning and debug

def get_file(filename):
    obj = s3.Object(base_bucket, filename).get()['Body']
    return obj

def get_token_from_s3():
    try:
        obj = get_file(okta_token_file_key).read()
        print('read token from s3--> '.format(obj))
    except Exception as e:
        logger.info('Read Token from S3 failed'.format(e))
        print('exception is ---'.format(e))
        gc.collect()
        obj = get_token()
        print('generated token --> '+obj)
    return obj

def get_token():
    print('getting token')
    headers = {'content-Type':'application/x-www-form-urlencoded'}
    r = requests.post(token_url,data=token_client_details,headers=headers)
    if r.status_code != 200:
        logger.error('Error in receiving token')
        raise Exception('Error in receiving token')
    access_token = json.loads(r.text)['access_token']
    return 'Bearer '+access_token

def get_data_for_accounts(dealers,token):
    resp = call_accountflex(dealers,token)
    if resp.status_code == 401:
        token_new = get_token()
        resp = call_accountflex(dealers,token_new)        
    if resp.status_code != 200:
        return {}
    return resp.json()

def call_accountflex(dealers,token):
    payload = {}
    payload['accountIdentifier'] = dealers
    headers = {
        'content-Type':'application/json',
        'Authorization':token
    }
    print(dealers)
    resp = requests.post(get_accounts_url, json=payload, headers=headers)
    logger.info('AccountFlex response code : %s',str(resp.status_code))
    return resp

def get_data_for_pins(pins,token):
    resp = call_pi(pins,token)
    if resp.status_code == 401:
        token_new = get_token()
        resp = call_pi(pins, token_new)
    if resp.status_code != 200:
        return {}
    return resp.json()

def call_pi(pins,token):
    params = {'serialNumbers': pins}
    headers = {
        'content-Type':'application/json',
        'Authorization':token,
        'Accepts-version':'V1'
    }
    resp = requests.get(find_product_url, params=params, headers=headers)
    logger.info('PI response code : %s',str(resp.status_code))        
    return resp

def get_expiry_date(data):
    if data['override_date']:
        return data['override_date']
    elif data['expiration_date']:
        return data['expiration_date']
    elif data['start_date'] and data['warranty_calculated_coverage']:
        start_date = datetime.datetime.strptime(data['start_date'], "%Y-%m-%d")
        end_date=start_date + datetime.timedelta(days=int(data['warranty_calculated_coverage']))
        return str(end_date).split(" ")[0]

    else:
        return ''

def remove_file_path_prefix(fullFilePath, sourceS3Folder):
    return fullFilePath[len(sourceS3Folder):] if fullFilePath.startswith(sourceS3Folder) else fullFilePath    

def move_file(sourceFile, targetFile):
    logger.info('In move_file, source file is: {} and target file is: {}'.format(sourceFile, targetFile))
    try:
        s3.Object(base_bucket, targetFile).copy_from(CopySource=base_bucket+'/'+sourceFile)
        s3.Object(base_bucket,sourceFile).delete()   
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
        
def lambda_handler(event, context):
    dealers = []
    pins = []
    try:
        inpFile = get_file(event['filename'])
        data = json.loads(inpFile.read())    
        for i in data:
            dealers.append(i['responsible_dealer'])
            pins.append(i['pin'])
        ###########Getting Account flex data############ 
        token = get_token_from_s3()
        dealers = list(filter(None, dealers))
        dealer_data = get_data_for_accounts(dealers,token)
        dealerMap = {}
        for i in dealer_data:
            dealerMap[i['accountId']] = i['accountLegalName'].strip()
        ###########Getting PI data############ 
        pins = list(filter(None, pins))
        pi_data = get_data_for_pins(pins,token)
        pinMap = {}
        if "products" in pi_data:
            for i in pi_data['products']:
                srNum=''
                for j in i['serialNumbers']:
                    exist = j['serialNumber'] in pins
                    if exist:
                        srNum=j['serialNumber']
                        break;        
                product_categories = i['productCategories']
                if product_categories:
                    pinMap[srNum] = product_categories[0].get('categoryName')
        final_data=[]   
        ###########Enriching Data############ 
        for i in data:
            i['dealerName']=dealerMap.get(i['responsible_dealer'],'')
            i['model']=pinMap.get(i['pin'],'')
            i['expiration_date']=get_expiry_date(i)
            final_data.append(i)
        print(final_data)
        #Move the source file to success folder for archive
        targetSuccessFile = success_s3_folder + remove_file_path_prefix(event['filename'], json_source_s3_folder)
        move_file(event['filename'],targetSuccessFile)
        s3object = s3.Object(base_bucket, event['filename'])
        s3object.put(Body=(bytes(json.dumps(final_data, indent=4).encode('UTF-8'))))
        return "success"
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
        gc.collect()
        #Move the source file to failure folder for archive
        targetErrorFile = failure_s3_folder + remove_file_path_prefix(event['filename'], json_source_s3_folder)
        move_file(event['filename'],targetErrorFile)
        return "failure"

if __name__ == "__main__":
    paylod={
        "filename": "DataMigrationToDynamoDb/jsonData/product_warranty_coverage_details-2019-x00/10.json"
    }
    enrichmentStatus = lambda_handler(paylod, None)
    print(enrichmentStatus)
