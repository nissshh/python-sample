import json
import os
import boto3
import logging
logger = logging.getLogger()

############Environment Variables############
base_bucket = os.environ.get('BASE_BUCKET','aws-channel-apps-devl-warranty')
fail_output_file_loc = os.environ.get('FAIL_OUTPUT_FILE_LOC','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/dataWriter/failure/')
success_output_file_loc = os.environ.get('SUCCESS_OUTPUT_FILE_LOC','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/dataWriter/success/')
table_name = os.environ.get('TABLE_NAME','channelwarranty.coverage.records')
environment = os.environ.get('ENVIRONMENT','devl')
log_level = os.environ.get('LOG_LEVEL','DEBUG')
logger.setLevel(log_level)

######S3 and DynamoDb Connection
s3 = boto3.resource('s3')
dynamodb = boto3.resource('dynamodb')

#TODO Add logging statemetns : info, warning and debug

def get_file(filename):
    obj = s3.Object(base_bucket, filename).get()['Body']
    return obj

def get_file_name(file,file_num):
    path_array = file.split('/')
    output_file_name=path_array[len(path_array)-2]+'/'+path_array[len(path_array)-1].replace('.json','')+'/'+str(file_num)+'.json'
    return output_file_name
    
def put_file_to_folder(file,data):
    s3object = s3.Object(base_bucket, file)
    s3object.put(Body=(bytes(json.dumps(data,indent=4).encode('UTF-8'))))

def delete_from_dynamo(data):
    table = dynamodb.Table(table_name)
    with table.batch_writer() as batch:
        for item in data:
            batch.delete_item(
                Key={
                    'dealer': item['dealer'],
                    'warr_prod_pk': item['warr_prod_pk']
                    }
                )

def write_to_dynamo(data):
    table = dynamodb.Table(table_name)
    with table.batch_writer() as batch:
        for item in data:
            batch.put_item(Item=item)
            
def lambda_handler(event, context):
    failed_load=[]
    succesful_load=[]
    json_data_dict = dict()
    batch_threshold = 20
    if event['dataMapperAndFilteringStatus']=='failure':
        logger.info('DataMapperAndFiltering Status was not successful. Marking data writing as failed')
        out_file_key=get_file_name(event['filename'],1)
        copy_source = {
            'Bucket': base_bucket,
            'Key': event['filename']
        }
        s3.meta.client.copy(copy_source, base_bucket, fail_output_file_loc+out_file_key)
        failed_data_dict = dict()
        failed_data_dict['filename']=fail_output_file_loc+out_file_key
        failed_load.append(failed_data_dict)
    logger.debug('Data writer processing starts')
    inp_file = get_file(event['filename'])
    inp_json_data = json.loads(inp_file.read())
    inp_count = len(inp_json_data)
    print('inp_count is - '+str(inp_count))
    batch_data=[]
    file_num=1
    for i in inp_json_data:
        out_file_key=get_file_name(event['filename'],file_num)
        batch_data.append(i)
        inp_count=inp_count-1
        print('batch length--'+str(len(batch_data))+' -- '+ str(inp_count))  
        if len(batch_data) >= batch_threshold or inp_count == 0 :
            try:
                delete_from_dynamo(batch_data)
                write_to_dynamo(batch_data)
                put_file_to_folder(success_output_file_loc+out_file_key,batch_data)
                batch_data.clear()
                success_data_dict = dict()
                success_data_dict['filename']=success_output_file_loc+out_file_key
                succesful_load.append(success_data_dict)
            except Exception as e:
                logger.error("Error executing dynamodb operations : ,Message:{}, Type:{}, Args:{}".format(e,type(e),e.args))
                put_file_to_folder(fail_output_file_loc+out_file_key,batch_data)
                batch_data.clear()
                failed_data_dict = dict()
                failed_data_dict['filename']=fail_output_file_loc+out_file_key
                failed_load.append(failed_data_dict)
            file_num=file_num+1     
    json_data_dict['succesfulLoad']=succesful_load
    json_data_dict['failedLoad']=failed_load
    json_data_string = json.dumps(json_data_dict, indent=4)
    logger.debug('Data writer response : %s',json_data_string)
    print(json_data_string)
    return json.loads(json_data_string)
 
if __name__ == "__main__":
    paylod={
        "filename": "DataMigrationToDynamoDb/jsonData/dataFilter/expiration/product_warranty_coverage_details-2013-x00/1.json",
        "dataEnrichmentStatus": "success",
        "dataMapperAndFilteringStatus": "success"
    }
    lambda_handler(paylod, None)