'''
Created on Jun 30, 2021

@author: nl02115
'''
import boto3
import os
import json
import logging
import csv
import gc

logger = logging.getLogger()
lambda_log_level=os.getenv('LOG_LEVEL','INFO')
logger.setLevel(lambda_log_level)

base_bucket = os.environ.get('BASE_BUCKET','aws-channel-apps-devl-warranty')
json_entries_threshold= os.environ.get('JSON_ENTRIES_THRESHOLD',100)
csv_header_file = os.environ.get('CSV_HEADER_FILE','DataMigrationToDynamoDb/referenceFiles/product_warranty_coverage_column_headers.csv')
source_csv_s3_folder = os.environ.get('SOURCE_CSV_S3_FOLDER','DataMigrationToDynamoDb/InputForStepFn/')
target_json_s3_folder = os.environ.get('TARGET_JSON_S3_FOLDER','DataMigrationToDynamoDb/jsonData/')
success_s3_folder = os.environ.get('SUCCESS_S3_FOLDER','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/covertFromCSVToJson/success/')
failure_s3_folder = os.environ.get('FAILURE_S3_FOLDER','DataMigrationToDynamoDb/archive/dataProcessComplete/expiration/covertFromCSVToJson/failure/')

s3_resource = boto3.resource('s3')

def get_filename_json_array(jsonDatafiles):
    logger.debug('Start get_filename_json_array')    
    logger.debug('jsonDatafiles is: {}'.format(jsonDatafiles))
    jsonDatafilesDict = dict()
    jsonDatafilesDict['jsonDatafiles'] = jsonDatafiles
    jsonDatafilesString = json.dumps(jsonDatafilesDict, indent=4)
    logger.info('jsonDatafilesString is: {}'.format(jsonDatafilesString))
    logger.debug('End get_filename_json_array')
    return jsonDatafilesString

    
def write_json_to_s3(json_array, filename):   
    logger.debug('Start write_json_to_s3') 
    logger.info('json_array is: {} ,filename is : {} '.format(json_array,filename))
    
    s3object = s3_resource.Object(base_bucket, filename)
    s3object.put(
        Body=(bytes(json.dumps(json_array,indent=4).encode('UTF-8')))
    )
    logger.debug('End write_json_to_s3') 

def write_json(json_array, filename):
    logger.debug('Start write_json')
    logger.info('json_array is: {} ,filename is : {} '.format(json_array,filename))
    
    with open(filename, 'w', encoding='UTF-8') as jsonf: 
        json.dump(json_array, jsonf, indent=4)  # note the usage of .dump directly to a file descriptor
    logger.debug('End write_json')
    
def csv_to_json(csvLines, s3_target_folder):
    logger.debug('Start csv_to_json')
    logger.info('s3_target_folder is: {}  '.format(s3_target_folder))
    
    jsonArray = []
    filename_index = 1
    jsonDatafiles = []
    
    for row in csvLines:
        jsonArray.append(row)
        if len(jsonArray) >= json_entries_threshold:
            # if we reached the threshold, write out
            write_json_to_s3(jsonArray, f"{target_json_s3_folder}{s3_target_folder}/{filename_index}.json")
            logger.debug('jsonArray is: {}  '.format(jsonArray))
            jsonDataDict = dict()
            jsonDataDict['filename'] = f"{target_json_s3_folder}{s3_target_folder}/{filename_index}.json"
            jsonDatafiles.append(jsonDataDict)
            filename_index += 1
            jsonArray = []
            
    # Finally, write out the remainder
    if len(jsonArray) > 0:
        write_json_to_s3(jsonArray, f"{target_json_s3_folder}{s3_target_folder}/{filename_index}.json")
        logger.debug('jsonArray is: {}  '.format(jsonArray))
        jsonDataDict = dict()
        jsonDataDict['filename'] = f"{target_json_s3_folder}{s3_target_folder}/{filename_index}.json"
        jsonDatafiles.append(jsonDataDict)
    logger.debug('End csv_to_json')
    return jsonDatafiles
    
def s3_csv_reader(object_key, delimiter):
    logger.debug('Start s3_csv_reader')
    logger.info('object_key is: {}, delimiter is: {}  '.format(object_key, delimiter))
    s3_header_object = s3_resource.Object(bucket_name=base_bucket, key=csv_header_file)
    header = s3_header_object.get()['Body'].read().decode('UTF-8').splitlines()
    
    s3_data_object = s3_resource.Object(bucket_name=base_bucket, key=object_key)
    data = s3_data_object.get()['Body'].read().decode('UTF-8').splitlines()

    data_with_header = header + data
    lines = csv.DictReader(data_with_header, delimiter=delimiter)
    logger.debug('End s3_csv_reader')
    return lines

def remove_file_path_prefix(fullFilePath, sourceS3Folder):
    return fullFilePath[len(sourceS3Folder):] if fullFilePath.startswith(sourceS3Folder) else fullFilePath    

def move_file(sourceFile, targetFile):
    logger.info('In move_file, source file is: {} and target file is: {}'.format(sourceFile, targetFile))
    try:
        s3_resource.Object(base_bucket, targetFile).copy_from(CopySource=base_bucket+'/'+sourceFile)
        s3_resource.Object(base_bucket,sourceFile).delete()   
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
   
def lambda_handler(event, context):
    logger.info('Lambda Started')   
    try:
        logger.info('Received Input : {}'.format(json.dumps(event, indent=2)))  
        
        object_key=event['csvDatafile']
        logger.info('dataFile is : {}'.format(object_key))  
    
        lines = s3_csv_reader(object_key = object_key, delimiter = ',')
        
        filename_without_folder_prefix = remove_file_path_prefix(object_key, source_csv_s3_folder)
        s3_target_folder = os.path.splitext(filename_without_folder_prefix)[0]
        logger.info('s3_target_folder is : {}'.format(s3_target_folder)) 
        
        
        jsonDatafiles = csv_to_json(lines, s3_target_folder)    
        logger.info('number_of_json_files is : {}'.format(len(jsonDatafiles))) 
        
        jsonDatafilesArray = get_filename_json_array(jsonDatafiles)
        
        json_obj = json.loads(jsonDatafilesArray)
        logger.info('json_obj is : {}'.format(json_obj))
        
        #Move the source file to success folder for archive
        targetSuccessFile = success_s3_folder + remove_file_path_prefix(event['csvDatafile'], source_csv_s3_folder)
        move_file(event['csvDatafile'],targetSuccessFile)
            
        return json_obj
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
        #Move the source file to success folder for archive
        targetErrorFile = failure_s3_folder + remove_file_path_prefix(event['csvDatafile'], source_csv_s3_folder)
        move_file(event['csvDatafile'],targetErrorFile)
        gc.collect()
        raise Exception({'message':'failed at convertFromCSVToJson lambda_handler', 'notificationCode':'', 'exception': format(e)})
    
    logger.info('Lambda End')
    
    
if __name__ == "__main__":
    paylod={
    "comment": "Warranty Expiration Report Full Load.",
    "current-timestamp": "2016-03-14T01:59:00Z",
    "csvDatafile": "DataMigrationToDynamoDb/InputForStepFn/product_warranty_coverage_details-2019-x00.csv"
    }
    jsonDatafilesArray = lambda_handler(paylod, None)
    print(jsonDatafilesArray)