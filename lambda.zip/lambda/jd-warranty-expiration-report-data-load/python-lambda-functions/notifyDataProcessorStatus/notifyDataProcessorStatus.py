'''
Created on Jul 7, 2021

@author: nl02115
'''
import json
import logging
import boto3
import os
import gc
from botocore.exceptions import ClientError

SUCCESS= 'SUCCESSFUL: '
FAILURE= 'FAILURE: '
ERROR = 'ERROR: '
WARNING = 'WARNING: '

logger = logging.getLogger()
lambda_log_level=os.getenv('LOG_LEVEL','INFO')
logger.setLevel(lambda_log_level)
aws_account_number=os.getenv('AWS_ACCOUNT_NUMBER','779476643188')

topicArn = f"arn:aws:sns:us-east-1:{aws_account_number}:channelwarranty-expiration-report-data-load-status"

snsClient = boto3.client('sns')

dynamoDbDataloadStatusAttribute = 'dynamoDbDataloadStatus'
succesfulLoadAttribute = 'succesfulLoad'
failedLoadAttribute = 'failedLoad'
fileNameAttribute = 'filename'
errorAttribute = 'error'
csvDatafileAttribute = 'csvDatafile'

def publish_message(topicArn, message, subject, messageAttributes):
    logger.debug('In publish_message')
    try:
        response = snsClient.publish(TopicArn=topicArn , Message=message, Subject=subject, MessageAttributes=messageAttributes)

        print(response['ResponseMetadata'])
        logger.info(
            "Published message with to topic %s , and response metadata is %s ", 
            topicArn,response['ResponseMetadata'])
    except ClientError:
        logger.exception("Couldn't publish message to topic %s.", topicArn)
        raise
    else:
        return response['ResponseMetadata']['HTTPStatusCode']

def prepare_and_publish_message(messageBody, subject, messageAttributes):
    
    logger.info('messageBody : {} ,subject: {} ,messageAttributes: {}'.format(messageBody, subject, messageAttributes))
    responseStatusCode = publish_message(topicArn, messageBody, subject, messageAttributes)
    logger.info('responseStatusCode is : {}'.format(responseStatusCode))
   
def lambda_handler(event, context):
    logger.info('Lambda Started') 
    try:
        logger.info('Received Input : {}'.format(event))  
        if dynamoDbDataloadStatusAttribute in event:
            #if (succesfulLoadAttribute in event[dynamoDbDataloadStatusAttribute]) and (len(event[dynamoDbDataloadStatusAttribute][succesfulLoadAttribute]) > 0):
            #    #publish for successful load
            #    messageAttributes = {"MessageStatus": { "DataType": "String", "StringValue": succesfulLoadAttribute}}
            #    subject = SUCCESS+event[fileNameAttribute]
            #    messageBody = json.dumps(event[dynamoDbDataloadStatusAttribute][succesfulLoadAttribute], indent=2)
            #    prepare_and_publish_message(messageBody, subject, messageAttributes)
            
            if (failedLoadAttribute in event[dynamoDbDataloadStatusAttribute]) and (len(event[dynamoDbDataloadStatusAttribute][failedLoadAttribute]) > 0):
                #publish for failed load
                messageAttributes = {"MessageStatus": { "DataType": "String", "StringValue": failedLoadAttribute}}
                subject = FAILURE +event[fileNameAttribute]
                messageBody = json.dumps(event[dynamoDbDataloadStatusAttribute][failedLoadAttribute], indent=2)
                prepare_and_publish_message(messageBody, subject, messageAttributes)

        elif errorAttribute in event:
            messageAttributes = {"MessageStatus": { "DataType": "String", "StringValue": errorAttribute}}
            if fileNameAttribute in event:
                subject = ERROR +event[fileNameAttribute]
            elif csvDatafileAttribute in event:
                subject = ERROR +event[csvDatafileAttribute]
            else:
                subject = ERROR
            messageBody = event[errorAttribute]['Cause']
            prepare_and_publish_message(messageBody, subject, messageAttributes)

        return "success"
    except Exception as e:
        logger.error('ERROR :: {} '.format(e))
        gc.collect()
        raise Exception(e)
    logger.info('Lambda End')

if __name__ == "__main__":
    paylod={
  "comment": "Warranty Expiration Report Full Load.",
  "current-timestamp": "2016-03-14T01:59:00Z",
  "csvDatafile": " DataMigrationToDynamoDb/InputForStepFn/product_warranty_coverage_details-2012-x00.csv",
  "error": {
    "Error": "Exception",
    "Cause": "{\"errorMessage\": \"{'message': 'failed at convertFromCSVToJson lambda_handler', 'notificationCode': '', 'exception': 'An error occurred (NoSuchKey) when calling the GetObject operation: The specified key does not exist.'}\", \"errorType\": \"Exception\", \"stackTrace\": [\"  File \\\"/var/task/lambda_function.py\\\", line 145, in lambda_handler\\n    raise Exception({'message':'failed at convertFromCSVToJson lambda_handler', 'notificationCode':'', 'exception': format(e)})\\n\"]}"
  }
}
    jsonDatafilesArray = lambda_handler(paylod, None)
    #print(jsonDatafilesArray)
    