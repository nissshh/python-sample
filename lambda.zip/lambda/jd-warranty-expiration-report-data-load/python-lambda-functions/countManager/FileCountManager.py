from pathlib import Path
from dotenv import load_dotenv
import os
import boto3
import datetime
import logging
logger = logging.getLogger()

############Environment Variables############
base_bucket = os.environ.get('BASE_BUCKET','aws-channel-apps-devl-warranty')
input_files_path = os.environ.get('INPUT_FILES_PATH','DataMigrationToDynamoDb/AfterFirstSplitting/')
output_files_path = os.environ.get('OUTPUT_FILES_PATH','DataMigrationToDynamoDb/InputForStepFn/')
environment = os.environ.get('ENVIRONMENT','devl')
max_instances = os.environ.get('MAX_INSTANCES','10')
log_level = os.environ.get('LOG_LEVEL','DEBUG')
logger.setLevel(log_level)

dirname = os.path.dirname(__file__)
env_path=dirname+'/env/'+environment+'.env'

dotenv_path = Path(env_path)
load_dotenv(dotenv_path=dotenv_path)
state_machine = os.environ.get('STATE_MACHINE_ARN')

######S3/Step Function Connection
s3 = boto3.resource('s3')
bucket = s3.Bucket(base_bucket)
step_client = boto3.client('stepfunctions')

#TODO Add logging statemetns : info, warning and debug

def get_count(filename):
    response = bucket.meta.client.list_objects_v2(Bucket=base_bucket,Prefix=filename)
    return response['KeyCount']

def get_stepFn_count():
    logger.debug('env Path : %s',env_path)
    logger.debug('state machine arn : %s',state_machine)
    response = step_client.list_executions(stateMachineArn=state_machine,statusFilter='RUNNING',maxResults=int(max_instances))
    stepCount=0
    for execution in response['executions']:
        stepCount=stepCount+1
    return stepCount

def lambda_handler(event, context):
    inpCount = get_count(input_files_path)
    logger.debug('Input file count : %s',str(inpCount))
    outCount = get_stepFn_count()
    print('outCount is: {} and inpCount: {}'.format(outCount,inpCount))
    logger.debug('Output file count : %s',str(outCount))          
    for obj in bucket.objects.filter(Prefix=input_files_path):
        if(outCount < int(max_instances) and inpCount > 0):
            if(obj.key.endswith(".csv")):
                copy_source = {
                    'Bucket': base_bucket,
                    'Key': obj.key
                }
                idx = obj.key.rindex("/")+1
                output_file=output_files_path+obj.key[idx:]
                s3.meta.client.copy(copy_source, base_bucket, output_file)
                tstamp = str(datetime.datetime.now())
                step_client.start_execution(stateMachineArn=state_machine,input="{\"csvDatafile\" : \"" + output_file + "\", \"comment\": \"Warranty Expiration Report Full Load\", \"current-timestamp\": \"" + tstamp + "\"}")
                
                outCount = outCount + 1
                print('step_client executed, and outCount is: {}'.format(outCount))
                s3.Object(base_bucket,obj.key).delete()
                inpCount = inpCount - 1
        else:
            break

if __name__ == "__main__":
    lambda_handler(None, None)
