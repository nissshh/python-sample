branch = "develop"
appName = "channelwarranty-dealer-classification-lambda"
git_url = "https://github.deere.com/channel-warranty/${GitServiceRepoName}.git"
git_token = "GitHubAppId"
instance = "Devl-1"
gitWebUrl = "https://github.deere.com/channel-warranty/${GitServiceRepoName}"
repositoryId = "channel-warranty-release-local"
repositoryUrl = "https://repository.deere.com/artifactory/channel-warranty-release-local"
jdwsMavenSettings = "fa5ae4d4-6370-4b90-b386-41901abcc0e1"
gitConfigName = "A908524"
triggerJobName="../../Deployment/Devl/release-deploy-${appName}-microservices"
mavenJob("/Build/Devl/release-${appName}-microservices") {
    label(instance)
    description('This job is to be only used for releasing artifacts for stamped releases , deploys to artifactory with Released version.')
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)    
	environmentVariables {
		 env('ARTIFACTORY_REPO_URL', repositoryUrl)
		 env('ARTIFACTORY_REPO_ID', repositoryId)
		 env('VERSION','')
		 keepBuildVariables(true)
	}
	
    scm {
	    git { 
            remote {
                url(git_url)
                credentials(git_token)
            }
            branch(branch)
			extensions {
				localBranch(branch)
				wipeOutWorkspace()
				
			}
			browser {
				gitWeb(gitWebUrl)
			}
			configure { node ->
				node / 'extensions' / 'hudson.plugins.git.extensions.impl.UserIdentity' << {
				delegate.name(gitConfigName)
				//email('f...@example.com')
				}
			}
		}
    }
	wrappers {        
        environmentVariables {
           env('LOG','DEBUG')
        }
		preBuildCleanup()
		colorizeOutput()
		timestamps()
		mavenRelease {
			releaseGoals('release:prepare release:perform')
			dryRunGoals('-DdryRun=true release:prepare')
			numberOfReleaseBuildsToKeep(1)
		}
		sshAgent('nishant_ssh_pvtkey')
	}
	rootPOM('pom.xml')
    goals('clean install')
	providedSettings(jdwsMavenSettings)
	postBuildSteps('SUCCESS') {
	shell('''#!/bin/bash
		echo maven project property - Jenkins environment variable
		echo POM_DISPLAYNAME=$POM_DISPLAYNAME
		echo POM_VERSION=$POM_VERSION
		echo POM_GROUPID=$POM_GROUPID
		echo POM_ARTIFACTID=$POM_ARTIFACTID
		echo POM_PACKAGING=$POM_PACKAGING
		echo GIT_AUTHOR_NAME=$GIT_AUTHOR_NAME
		echo GIT_COMMITTER_NAME=$GIT_COMMITTER_NAME
		echo GIT_AUTHOR_EMAIL=$GIT_AUTHOR_EMAIL
		echo GIT_COMMITTER_EMAIL=$GIT_COMMITTER_EMAIL
	''')
	}
	publishers {
		buildDescription(/.*\* Version: *([^\s]*)/)
		wsCleanup {
			failBuildWhenCleanupFails(true)
			deleteDirectories(true)
		}
		downstreamParameterized {
			trigger(triggerJobName) {
				condition('SUCCESS')
				parameters {
					predefinedProp('GROUP','$POM_GROUPID')
					predefinedProp('ARTIFACT','$POM_ARTIFACTID')
					predefinedProp('VERSION','$POM_VERSION')
					predefinedProp('FILE_TYPE','.$POM_PACKAGING')
					predefinedProp('ARTIFACTORY_REPO_URL','$ARTIFACTORY_REPO_URL')
					predefinedProp('ARTIFACTORY_REPO_ID','$ARTIFACTORY_REPO_ID')
				}
			}
		}
	}
}
