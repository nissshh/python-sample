branch = "${GitServiceBranch}"
appName = "channelwarranty-dealer-classification-lambda"
git_url = "https://github.deere.com/channel-warranty/${GitServiceRepoName}.git"
git_token = "GitHubAppId"
instance = "Devl-1"
gitWebUrl = "https://github.deere.com/channel-warranty/${GitServiceRepoName}"
jdwsMavenSettings = "fa5ae4d4-6370-4b90-b386-41901abcc0e1"
gitConfigName = "A908524"
mavenJob("/Build/Devl/build-${appName}-microservices") {  
    label(instance)
    description('This job is to be only used for releasing artifacts for stamped releases , deploys to artifactory with Released version.')
    logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1) 
    scm {
	    git { 
            remote {
                url(git_url)
                credentials(git_token)
            }
            branch(branch)
			extensions {
				localBranch(branch)
				wipeOutWorkspace()
			}
			browser {
				gitWeb(gitWebUrl)
			}
		}
    }
	wrappers {        
        environmentVariables {
           env('LOG','DEBUG')
        }
		preBuildCleanup()
		colorizeOutput()
		timestamps()
	}
	rootPOM('pom.xml')
    goals('clean install package')
	providedSettings(jdwsMavenSettings)
	postBuildSteps('SUCCESS') {
	shell('''#!/bin/bash
		echo maven project property - Jenkins environment variable
		echo POM_DISPLAYNAME=$POM_DISPLAYNAME
		echo POM_VERSION=$POM_VERSION
		echo POM_GROUPID=$POM_GROUPID
		echo POM_ARTIFACTID=$POM_ARTIFACTID
		echo POM_PACKAGING=$POM_PACKAGING
		echo GIT_AUTHOR_NAME=$GIT_AUTHOR_NAME
		echo GIT_COMMITTER_NAME=$GIT_COMMITTER_NAME
		echo GIT_AUTHOR_EMAIL=$GIT_AUTHOR_EMAIL
		echo GIT_COMMITTER_EMAIL=$GIT_COMMITTER_EMAIL
	''')
	}
	publishers {
		wsCleanup {
			failBuildWhenCleanupFails(true)
			deleteDirectories(true)
		}
	}
}