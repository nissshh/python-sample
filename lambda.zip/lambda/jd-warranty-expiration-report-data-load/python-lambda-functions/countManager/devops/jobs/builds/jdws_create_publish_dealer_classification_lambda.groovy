branch = "${GitServiceBranch}"
appName = "channelwarranty-dealer-classification-lambda"
git_url = "https://github.deere.com/channel-warranty/${GitServiceRepoName}.git"
git_token = "GitHubAppId"
instance = "Devl-1"
repositoryId = "channel-warranty-release-local"
repositoryUrl = "https://repository.deere.com/artifactory/channel-warranty-release-local"
gitWebUrl = "https://github.deere.com/channel-warranty/${GitServiceRepoName}"
jdwsMavenSettings = "fa5ae4d4-6370-4b90-b386-41901abcc0e1"
gitConfigName = "A908524"
triggerJobName="../../Deployment/Devl/snapshot-deploy-${appName}-microservices"
mavenJob("/Build/Devl/publish-${appName}-microservices") {
	label(instance)
	description('This job is to be only used for releasing artifacts for stamped releases , deploys to artifactory with Released version.')
	logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)    
	environmentVariables {
		 env('ARTIFACTORY_REPO_URL', repositoryUrl)
		 env('ARTIFACTORY_REPO_ID', repositoryId)
		 env('VERSION','')
		 keepBuildVariables(true)
	}
	scm {
		git { 
			remote {
				url(git_url)
				credentials(git_token)
			}
			branch(branch)
			extensions {
				localBranch(branch)
				wipeOutWorkspace()
			}
			browser {
				gitWeb(gitWebUrl)
			}
		}
    }
	wrappers {        
		environmentVariables {
			env('LOG','DEBUG')
		}
		preBuildCleanup()
		colorizeOutput()
		timestamps()
		credentialsBinding {
			file('MAVEN_SETTINGS', 'settings.xml')
			string('API_KEY', 'AppIdArtifactoryAPIKey')
			usernamePassword('MAVEN_USER', 'MAVEN_PASSWORD', 'AppIDArtifactoryUser')
		}

	}
	rootPOM('pom.xml')
	goals('clean install')
	providedSettings(jdwsMavenSettings)
	postBuildSteps('SUCCESS') {
		shell('''#!/bin/bash
			echo maven project property - Jenkins environment variable
			echo POM_DISPLAYNAME=$POM_DISPLAYNAME
			echo POM_VERSION=$POM_VERSION
			echo POM_GROUPID=$POM_GROUPID
			echo POM_ARTIFACTID=$POM_ARTIFACTID
			echo POM_PACKAGING=$POM_PACKAGING
			echo GIT_AUTHOR_NAME=$GIT_AUTHOR_NAME
			echo GIT_COMMITTER_NAME=$GIT_COMMITTER_NAME
			echo GIT_AUTHOR_EMAIL=$GIT_AUTHOR_EMAIL
			echo GIT_COMMITTER_EMAIL=$GIT_COMMITTER_EMAIL
			echo ARTIFACTORY_REPO_URL=$ARTIFACTORY_REPO_URL
			echo ARTIFACTORY_REPO_ID=$ARTIFACTORY_REPO_ID
			
		''')
		shell('''#!/bin/bash
			major_verson=0
			minor_version=0
			patch_version=0
			url="https://repository.deere.com/artifactory/api/search/latestVersion?g=$POM_GROUPID&a=$POM_ARTIFACTID&repos=$ARTIFACTORY_REPO_ID&remote=1"
			echo $url
			VERSION=$(curl -s --header "x-api-key: $API_KEY" $url)
			VER=$?
			if [ $VER -gt 0 ]; then
				exit 1
			fi
			echo "Version to be used from Artifactory:$VERSION"
			regex="([0-9]+).([0-9]+).([0-9]+)"
			major_verson="$(echo $VERSION | cut -d'.' -f1)"
			minor_version="$(echo $VERSION | cut -d'.' -f2)"
			patch_version="$(echo $VERSION | cut -d'.' -f3)"
			patch_version="$(echo $patch_version | cut -d'-' -f1)"
			patch_version=$((patch_version+1))
			echo "Versions are Major:$major_verson | Minor:$minor_version | Patch:$patch_version"
			VERSION=${major_verson}.${minor_version}.${patch_version}
			VERSION=$VERSION-Release
			echo "new version: $VERSION"
			mvn -B -s $MAVEN_SETTINGS deploy:deploy-file -DgroupId=$POM_GROUPID -DartifactId=$POM_ARTIFACTID -Dversion=$VERSION -Dfile=target/$POM_ARTIFACTID.jar -Dpackaging=jar -DrepositoryId=$ARTIFACTORY_REPO_ID -Durl=$ARTIFACTORY_REPO_URL
			STATUS=$?
			if [ $STATUS -eq 0 ]; then
				echo "Deployment Successful"
				echo -e "
				********** Build Information **********
				* Version: $VERSION
				***************************************"
			else
				echo "Deployment Failed"
				exit 1
			fi
		''')
	}
	publishers {
		buildDescription(/.*\* Version: *([^\s]*)/)									 
		wsCleanup {
			failBuildWhenCleanupFails(true)
			deleteDirectories(true)
		}	 
		downstreamParameterized {
			trigger(triggerJobName) {
				condition('SUCCESS')
				parameters {
					predefinedProp('GROUP','$POM_GROUPID')
					predefinedProp('ARTIFACT','$POM_ARTIFACTID')
					predefinedProp('FILE_TYPE','.jar')
					predefinedProp('ARTIFACTORY_REPO_URL','$ARTIFACTORY_REPO_URL')
					predefinedProp('ARTIFACTORY_REPO_ID','$ARTIFACTORY_REPO_ID')
				}
			}
		}
	}
}