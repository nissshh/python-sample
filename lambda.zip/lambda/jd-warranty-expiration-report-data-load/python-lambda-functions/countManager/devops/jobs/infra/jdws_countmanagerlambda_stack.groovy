appName = "channelwarranty-count-manager-lambda"
branch = "${GitServiceBranch}"
git_url = "https://github.deere.com/channel-warranty/${GitServiceRepoName}.git"
git_token = "GitHubAppId"
instance = "${Env}-1"
environ = "${Env}"

freeStyleJob("/Infrastructure/${Env}/jdws-${appName}-stack") {
	label(instance)
	logRotator(numToKeep = 100)
	environmentVariables {
		if (environ=='Prod') {
			env('ACCOUNT_NUMBER', '518348415604')
				env('ACCOUNT_NAME','aws-channel-apps-prod')
				env('ENVIRONMENT','prod')
		} else {
			if(environ=='Qual') {
				env('ACCOUNT_NUMBER', '796414610245')
				env('ACCOUNT_NAME','aws-channel-apps-qual')
				env('ENVIRONMENT','qual')
				}
			else {
				env('ACCOUNT_NUMBER', '779476643188')
				env('ACCOUNT_NAME','aws-channel-apps-devl')
				env('ENVIRONMENT','devl')
			}
		}
	}
	parameters {
		stringParam("ACCOUNT_ALIAS", "aws-channel-apps")
		stringParam("ROLE_NAME", "jenkins/appslave-jenkins-channeljdws", "Jenkins role")
		choiceParam("OPERATION", ["deploy", "delete"])
		stringParam("APP_NAME", "${appName}", "DO NOT CHANGE THIS, CHANGE IN GROOVY FILE FOR CLASS")
		labelParam("NODE"){
			defaultValue(instance)
		}
	}
	
	scm {
		git {
			remote {
				url(git_url)
				credentials(git_token)
			}
			branch(branch)
		}
	}
	wrappers {
		preBuildCleanup()
	}
	steps {
		shell('''#!/bin/bash
			echo "Account Number to be used:$ACCOUNT_NUMBER"
			echo "Environment to be used:$ENVIRONMENT"
			
			ARCH_FILE=devops/aws-cloudformation/arch-yamls/arch-count-manager-lambda.j2
			VAR_FILE=devops/aws-cloudformation/var-files/$ENVIRONMENT/$ENVIRONMENT-countmanagerlambda.yml
			STACK_NAME=${APP_NAME}
			CONFIG_FILE=devops/aws-cloudformation/config/$ENVIRONMENT-stack-params.config
			TEMPLATE_URL=$ACCOUNT_ALIAS-$ENVIRONMENT-useast1-vpn-system/templates/slave-jenkins/${APP_NAME}.json
			ROLE_NAME=$ROLE_NAME
			
			if [ "$RE_CREATE" = false ]
			then
				FORCE_DELETE=""
			else
				FORCE_DELETE=--force_delete
			fi
			
			python --version
			python -m cloud_common.aws_stack_operation \\
			--region us-east-1 \\
			--role_name $ROLE_NAME \\
			--account_number $ACCOUNT_NUMBER \\
			--operation $OPERATION \\
			--arch $ARCH_FILE \\
			--var $VAR_FILE \\
			--stack_name $STACK_NAME \\
			--config_file $CONFIG_FILE \\
			--template_url $TEMPLATE_URL \\
			--log DEBUG $FORCE_DELETE $USE_EXISTING
		''')
	}
}
