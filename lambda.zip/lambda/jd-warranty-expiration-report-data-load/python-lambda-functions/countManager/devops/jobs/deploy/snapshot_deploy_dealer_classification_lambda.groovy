branch = "${GitServiceBranch}"
appName = "channelwarranty-dealer-classification-lambda"
git_url = "https://github.deere.com/channel-warranty/${GitServiceRepoName}.git"
git_token = "GitHubAppId"
instance = "Devl-1"
triggerJobName="../../Infrastructure/Devl/jdws-${appName}-stack"

freeStyleJob("/Deployment/Devl/snapshot-deploy-${appName}-microservices") {
	label(instance)
	description 'Deploys Microservices App ${appName} to DEVL environment.'
	logRotator(daysToKeep = -1, numToKeep = 10, artifactDaysToKeep = -1, artifactNumToKeep = -1)    
	wrappers {        
		environmentVariables {
			env('LOG','DEBUG')
		}
		preBuildCleanup()
		colorizeOutput()
		timestamps()
		credentialsBinding {
			file('MAVEN_SETTINGS', 'settings.xml')
			usernamePassword('MAVEN_USER', 'MAVEN_PASSWORD', 'AppIDArtifactoryUser')
		}
	}
	parameters {
		//Package Details -- will come from upstream
		stringParam('OldVersion','','Leave this blank for most recent version available on Artifactory, otherwise specify version requested in 0.0.5 format.')
		stringParam('GROUP','com.deere.channel.jdws.aws','Optional: Project artifact group id i.e., com.deere.oca')
		stringParam('ARTIFACT','jd-warranty-delta-dealer-classification-lambda','Optional: Project artifact name i.e., asset-api')
		stringParam('FILE_TYPE','.jar','Optional: Project artifact name i.e., asset-api')
		stringParam('BUCKET_NAME','aws-channel-apps-devl-warranty','Required: S3 bucket for app aws package bundle i.e., aws-channel-apps-devl-glidepath')
		stringParam('ARTIFACTORY_REPO_ID','channel-warranty-release-local','Artifactory Repository Id, from upstream.')
		stringParam('API_KEY','AKCp5dKZ7qJJMGmRCE5mfrNNMa6oc6Di6Ro2vHJSuR3BGHV7TLzTEe6Ud2YZf8jNy5gk5vGf3','API Key for Artifactory')
	}
	wrappers{
		environmentVariables {
		env('LOG','DEBUG')
		}
		preBuildCleanup()
	}
	steps{
		shell('''#!/bin/bash
			if [ -z $OldVersion ]
			then
				url="https://repository.deere.com/artifactory/api/search/latestVersion?g=$GROUP&a=$ARTIFACT&repos=$ARTIFACTORY_REPO_ID"
				echo $url
				VERSION=$(curl -s --header "x-api-key: $API_KEY" $url)
                VER=$?
				if [ $VER -gt 0 ]; then
					exit 1
				fi
			echo "Version to be used from Artifactory:$VERSION"
			elif [[ $OldVersion =~ ^[0-9]+\\.[0-9]+\\.[0-9]+$ ]]
			then
				VERSION="$OldVersion-Release"
				echo "Version to be used:$VERSION"
			else
				echo "Version not in correct format of 0.0.2"
				exit 1
			fi

			mvn -s $MAVEN_SETTINGS dependency:copy -Dartifact=$GROUP:$ARTIFACT:$VERSION -DoutputDirectory=target
            STATUS=$?
            if [ $STATUS -ne 0 ]; then
            	exit 1
            fi
			aws s3 cp target/$ARTIFACT-$VERSION.jar s3://$BUCKET_NAME/LambdaPackages/$ARTIFACT.jar
			UPLOAD=$?
            if [ $UPLOAD -eq 0 ]; then
            	echo 'Deployment completed.'
            else
            	echo "Deployment Failed"
				exit 1
			fi
			''')
	}
	publishers {
		wsCleanup {
			failBuildWhenCleanupFails(true)
			deleteDirectories(true)
		}
		publishers {
        downstream(triggerJobName, 'SUCCESS')
		}
	}
}
