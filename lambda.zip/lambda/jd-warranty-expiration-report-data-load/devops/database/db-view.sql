drop view if exists deere_warranty.vw_product_warranty_coverage_details cascade;
CREATE OR REPLACE VIEW deere_warranty.vw_product_warranty_coverage_details AS 
select pw.warranty_product_pk as warr_prod_pk, pm.productmaster_pk as productmaster_pk, prg.registration_pk as registration_pk, de.dealer_pk as dealer_pk, cu.customer_pk as customer_pk,
mh.warranty_master_pk as warranty_master_pk, po.warranty_product_pk as warranty_override_pk, exc.warranty_extended_contract_pk as warranty_extended_contract_pk, wmc.warranty_counter_pk as warranty_counter_pk,
pw.legacy_pin_num as pin, de.dealer_id as responsible_dealer, cu.sap_customer_num as sap_customer_num, 
pw.warranty_master_num as warranty_master_num, pw.warranty_type_cd as warranty_type_cd, mh.warrant_text as warranty_type_txt, 
pw.valid_from_dt as start_date, pw.valid_to_dt as expiration_date, pw.deletion_ind as deletion_ind, pw.pass_on_wty as pass_on_wty, 
po.override_end_dt as override_date, exc.contract_date as contract_purchase_date, exc.warranty_master_cancel_ind as warranty_cancel_ind, 
wmc.warranty_counter_name as warranty_counter_name, wmc.warranty_counter_value, wmc.warranty_calculated_coverage,
pw.src_created_on_dt as warr_created_dt, pw.created_ts as warr_created_ts, pw.updated_ts warr_updated_ts, pm.created_ts as pm_created_ts, pm.updated_ts as pm_updated_ts, 
po.created_ts as po_created_ts, po.updated_ts as po_updated_ts, exc.created_on as exc_created_ts, exc.changed_date as exc_updated_ts
from deere_warranty.product_warranty pw 
inner join deere_warranty.productmaster pm on pw.legacy_pin_num  = pm.pin_num
left join deere_warranty.dealer de on pm.responsible_dealer_fk = de.dealer_pk
left join deere_warranty.productregistration prg on pm.productmaster_pk = prg.productmaster_fk
left join deere_warranty.customer cu on prg.customer_fk = cu.customer_pk
left join deere_warranty.warranty_master_header mh on pw.warranty_master_fk = mh.warranty_master_pk
left join deere_warranty.product_warranty_override po on pw.legacy_pin_num = po.legacy_pin_num and pw.warranty_type_cd =  po.warranty_type_cd
left join deere_warranty.warranty_extended_contract exc on pw.legacy_pin_num = exc.pin_num and pw.warranty_master_num = exc.warranty_master_num
left join deere_warranty.warranty_master_counter wmc on pw.warranty_master_num = wmc.warranty_master_num and wmc.warranty_counter_name='WTY_DAYS' 
