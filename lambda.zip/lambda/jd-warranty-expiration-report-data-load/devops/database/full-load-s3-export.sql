SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2021-01-01$$ and $$2021-12-31$$ order by warr_prod_pk', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2021.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2020-01-01$$ and $$2020-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2020.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2019-01-01$$ and $$2019-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2019.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2018-01-01$$ and $$2018-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2018.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2017-01-01$$ and $$2017-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2017.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2016-01-01$$ and $$2016-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2016.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2015-01-01$$ and $$2015-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2015.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2014-01-01$$ and $$2014-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2014.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2013-01-01$$ and $$2013-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2013.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2012-01-01$$ and $$2012-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2012.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2011-01-01$$ and $$2011-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2011.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt between $$2010-01-01$$ and $$2010-12-31$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2010.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');

SELECT * from aws_s3.query_export_to_s3('select  * from deere_warranty.vw_product_warranty_coverage_details
where productmaster_pk not in (select productmaster_fk from deere_warranty.productstausmap where product_status_cd_rk in ($$I0320$$, $$I0076$$)) 
and warr_created_dt < $$2010-01-01$$', 
   aws_commons.create_s3_uri('aws-channel-apps-devl-warranty', 'DataMigrationToDynamoDb/ExportToS3/product_warranty_coverage_details-2009-older.csv', 'us-east-1') 
, options :='format csv, delimiter $$,$$');
